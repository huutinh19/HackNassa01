
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.MimeMessage;

public class SendMail {
    public static void main(String[] args){
        String username = "dttvn0010@gmail.com";
        //https://myaccount.google.com/u/2/apppasswords
        String password = "gtbj mjgj xwyn zbrr"; // app password
        
        String to = "duongthanhtungvn01@gmail.com";
        String title = "Hello";
        String content = "Hello, how are you";
        
        Properties props = new Properties();
        props.setProperty("mail.smtp.auth", "true");
        props.setProperty("mail.smtp.auth", "true");
        props.setProperty("mail.smtp.starttls.enable", "true");
        props.setProperty("mail.smtp.host", "smtp.gmail.com");
        props.setProperty("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        MimeMessage msg = new MimeMessage(session);
        
        try {
            msg.setRecipients(Message.RecipientType.TO, to);
            msg.setSubject(title);
            msg.setText(content);
            Transport.send(msg);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
