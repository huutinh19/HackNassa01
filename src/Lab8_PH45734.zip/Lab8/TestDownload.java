
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class TestDownload {
    public static void main(String[] args) throws MalformedURLException, IOException {
        URL url = new URL("https://cdnphoto.dantri.com.vn/oeovo6AF4YjrcklJtezBndFzFlk=/zoom/504_336/2023/11/21/img3781-crop-edited-1700583648674.jpeg");
        FileOutputStream fo = new FileOutputStream("C:\\test\\img1.jpg");
        InputStream is = url.openStream();
        byte[] buf = new byte[4096];
        while(true) {
            int n = is.read(buf);
            if(n <= 0) break;
            fo.write(buf, 0, n);
        }
        is.close();
        fo.close();
    }
}
